
# Create comprehensive backend code structure for the mock e-commerce cart project

backend_code = {
    "server.js": '''// server.js - Main Express server file
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// MongoDB Connection
const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/vibe-commerce';

mongoose.connect(MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => console.log('✅ MongoDB Connected Successfully'))
.catch((err) => console.error('❌ MongoDB Connection Error:', err));

// Import Routes
const productRoutes = require('./routes/products');
const cartRoutes = require('./routes/cart');
const checkoutRoutes = require('./routes/checkout');

// API Routes
app.use('/api/products', productRoutes);
app.use('/api/cart', cartRoutes);
app.use('/api/checkout', checkoutRoutes);

// Health Check Route
app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', message: 'Vibe Commerce API is running' });
});

// Error Handling Middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ 
    error: 'Something went wrong!', 
    message: err.message 
  });
});

// Start Server
app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
  console.log(`📡 API available at http://localhost:${PORT}/api`);
});
''',

    "package.json": '''{
  "name": "vibe-commerce-backend",
  "version": "1.0.0",
  "description": "Backend API for Vibe Commerce Shopping Cart",
  "main": "server.js",
  "scripts": {
    "start": "node server.js",
    "dev": "nodemon server.js",
    "seed": "node utils/seedProducts.js",
    "test": "echo \\"Error: no test specified\\" && exit 1"
  },
  "keywords": ["ecommerce", "shopping-cart", "express", "mongodb", "rest-api"],
  "author": "Your Name",
  "license": "MIT",
  "dependencies": {
    "express": "^4.18.2",
    "mongoose": "^7.5.0",
    "cors": "^2.8.5",
    "dotenv": "^16.3.1"
  },
  "devDependencies": {
    "nodemon": "^3.0.1"
  }
}
''',

    ".env.example": '''# Environment Variables Template
# Copy this file to .env and fill in your values

# Server Configuration
PORT=5000
NODE_ENV=development

# MongoDB Configuration
# Local MongoDB
MONGO_URI=mongodb://localhost:27017/vibe-commerce

# OR MongoDB Atlas (Cloud)
# MONGO_URI=mongodb+srv://<username>:<password>@cluster.mongodb.net/vibe-commerce?retryWrites=true&w=majority

# Mock User ID (for testing)
DEFAULT_USER_ID=user_12345
''',

    ".gitignore": '''# Dependencies
node_modules/
package-lock.json
yarn.lock

# Environment Variables
.env
.env.local
.env.production

# Logs
logs
*.log
npm-debug.log*

# OS Files
.DS_Store
Thumbs.db

# IDE
.vscode/
.idea/
*.swp
*.swo

# Build
dist/
build/
''',

    "models/Product.js": '''// models/Product.js - Product Schema
const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, 'Product title is required'],
    trim: true
  },
  price: {
    type: Number,
    required: [true, 'Product price is required'],
    min: [0, 'Price cannot be negative']
  },
  description: {
    type: String,
    default: ''
  },
  category: {
    type: String,
    default: 'general'
  },
  image: {
    type: String,
    default: 'https://via.placeholder.com/300'
  },
  rating: {
    rate: {
      type: Number,
      default: 0,
      min: 0,
      max: 5
    },
    count: {
      type: Number,
      default: 0
    }
  },
  stock: {
    type: Number,
    default: 100
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('Product', productSchema);
''',

    "models/Cart.js": '''// models/Cart.js - Cart Schema
const mongoose = require('mongoose');

const cartItemSchema = new mongoose.Schema({
  productId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Product',
    required: true
  },
  title: {
    type: String,
    required: true
  },
  price: {
    type: Number,
    required: true
  },
  image: {
    type: String,
    required: true
  },
  quantity: {
    type: Number,
    required: true,
    min: [1, 'Quantity must be at least 1'],
    max: [10, 'Quantity cannot exceed 10'],
    default: 1
  }
});

const cartSchema = new mongoose.Schema({
  userId: {
    type: String,
    required: true,
    default: 'user_12345'
  },
  items: [cartItemSchema],
  subtotal: {
    type: Number,
    default: 0
  },
  tax: {
    type: Number,
    default: 0
  },
  total: {
    type: Number,
    default: 0
  }
}, {
  timestamps: true
});

// Calculate cart totals before saving
cartSchema.pre('save', function(next) {
  this.subtotal = this.items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  this.tax = this.subtotal * 0.10; // 10% tax
  this.total = this.subtotal + this.tax;
  next();
});

module.exports = mongoose.model('Cart', cartSchema);
''',

    "models/Order.js": '''// models/Order.js - Order Schema
const mongoose = require('mongoose');

const orderItemSchema = new mongoose.Schema({
  productId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Product'
  },
  title: String,
  price: Number,
  quantity: Number
});

const orderSchema = new mongoose.Schema({
  orderId: {
    type: String,
    required: true,
    unique: true
  },
  userId: {
    type: String,
    required: true
  },
  customerName: {
    type: String,
    required: true
  },
  customerEmail: {
    type: String,
    required: true
  },
  customerPhone: String,
  customerAddress: String,
  items: [orderItemSchema],
  subtotal: {
    type: Number,
    required: true
  },
  tax: {
    type: Number,
    required: true
  },
  total: {
    type: Number,
    required: true
  },
  status: {
    type: String,
    enum: ['pending', 'processing', 'completed', 'cancelled'],
    default: 'pending'
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('Order', orderSchema);
''',

    "routes/products.js": '''// routes/products.js - Product Routes
const express = require('express');
const router = express.Router();
const Product = require('../models/Product');

// @route   GET /api/products
// @desc    Get all products (with optional limit)
// @access  Public
router.get('/', async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 10;
    const products = await Product.find().limit(limit);
    
    res.json({
      success: true,
      count: products.length,
      data: products
    });
  } catch (error) {
    console.error('Error fetching products:', error);
    res.status(500).json({
      success: false,
      error: 'Server Error',
      message: error.message
    });
  }
});

// @route   GET /api/products/:id
// @desc    Get single product by ID
// @access  Public
router.get('/:id', async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    
    if (!product) {
      return res.status(404).json({
        success: false,
        error: 'Product not found'
      });
    }
    
    res.json({
      success: true,
      data: product
    });
  } catch (error) {
    console.error('Error fetching product:', error);
    res.status(500).json({
      success: false,
      error: 'Server Error',
      message: error.message
    });
  }
});

// @route   POST /api/products
// @desc    Create a new product (Admin only - for seeding)
// @access  Public (should be Protected in production)
router.post('/', async (req, res) => {
  try {
    const product = await Product.create(req.body);
    
    res.status(201).json({
      success: true,
      data: product
    });
  } catch (error) {
    console.error('Error creating product:', error);
    res.status(400).json({
      success: false,
      error: 'Validation Error',
      message: error.message
    });
  }
});

module.exports = router;
''',

    "routes/cart.js": '''// routes/cart.js - Cart Routes
const express = require('express');
const router = express.Router();
const Cart = require('../models/Cart');
const Product = require('../models/Product');

const DEFAULT_USER_ID = process.env.DEFAULT_USER_ID || 'user_12345';

// @route   GET /api/cart
// @desc    Get user's cart
// @access  Public
router.get('/', async (req, res) => {
  try {
    const userId = req.query.userId || DEFAULT_USER_ID;
    let cart = await Cart.findOne({ userId });
    
    // Create empty cart if doesn't exist
    if (!cart) {
      cart = await Cart.create({ userId, items: [] });
    }
    
    res.json({
      success: true,
      data: cart
    });
  } catch (error) {
    console.error('Error fetching cart:', error);
    res.status(500).json({
      success: false,
      error: 'Server Error',
      message: error.message
    });
  }
});

// @route   POST /api/cart
// @desc    Add item to cart
// @access  Public
router.post('/', async (req, res) => {
  try {
    const { productId, quantity = 1 } = req.body;
    const userId = req.body.userId || DEFAULT_USER_ID;
    
    // Validate product exists
    const product = await Product.findById(productId);
    if (!product) {
      return res.status(404).json({
        success: false,
        error: 'Product not found'
      });
    }
    
    // Find or create cart
    let cart = await Cart.findOne({ userId });
    if (!cart) {
      cart = new Cart({ userId, items: [] });
    }
    
    // Check if item already in cart
    const itemIndex = cart.items.findIndex(
      item => item.productId.toString() === productId
    );
    
    if (itemIndex > -1) {
      // Update quantity (max 10)
      cart.items[itemIndex].quantity = Math.min(
        cart.items[itemIndex].quantity + quantity,
        10
      );
    } else {
      // Add new item
      cart.items.push({
        productId: product._id,
        title: product.title,
        price: product.price,
        image: product.image,
        quantity: Math.min(quantity, 10)
      });
    }
    
    await cart.save();
    
    res.json({
      success: true,
      message: 'Item added to cart',
      data: cart
    });
  } catch (error) {
    console.error('Error adding to cart:', error);
    res.status(500).json({
      success: false,
      error: 'Server Error',
      message: error.message
    });
  }
});

// @route   PUT /api/cart/:productId
// @desc    Update item quantity in cart
// @access  Public
router.put('/:productId', async (req, res) => {
  try {
    const { productId } = req.params;
    const { quantity } = req.body;
    const userId = req.body.userId || DEFAULT_USER_ID;
    
    const cart = await Cart.findOne({ userId });
    if (!cart) {
      return res.status(404).json({
        success: false,
        error: 'Cart not found'
      });
    }
    
    const itemIndex = cart.items.findIndex(
      item => item.productId.toString() === productId
    );
    
    if (itemIndex === -1) {
      return res.status(404).json({
        success: false,
        error: 'Item not found in cart'
      });
    }
    
    // Update quantity (min 1, max 10)
    cart.items[itemIndex].quantity = Math.max(1, Math.min(quantity, 10));
    
    await cart.save();
    
    res.json({
      success: true,
      message: 'Cart updated',
      data: cart
    });
  } catch (error) {
    console.error('Error updating cart:', error);
    res.status(500).json({
      success: false,
      error: 'Server Error',
      message: error.message
    });
  }
});

// @route   DELETE /api/cart/:productId
// @desc    Remove item from cart
// @access  Public
router.delete('/:productId', async (req, res) => {
  try {
    const { productId } = req.params;
    const userId = req.query.userId || DEFAULT_USER_ID;
    
    const cart = await Cart.findOne({ userId });
    if (!cart) {
      return res.status(404).json({
        success: false,
        error: 'Cart not found'
      });
    }
    
    cart.items = cart.items.filter(
      item => item.productId.toString() !== productId
    );
    
    await cart.save();
    
    res.json({
      success: true,
      message: 'Item removed from cart',
      data: cart
    });
  } catch (error) {
    console.error('Error removing from cart:', error);
    res.status(500).json({
      success: false,
      error: 'Server Error',
      message: error.message
    });
  }
});

// @route   DELETE /api/cart
// @desc    Clear entire cart
// @access  Public
router.delete('/', async (req, res) => {
  try {
    const userId = req.query.userId || DEFAULT_USER_ID;
    
    const cart = await Cart.findOne({ userId });
    if (!cart) {
      return res.status(404).json({
        success: false,
        error: 'Cart not found'
      });
    }
    
    cart.items = [];
    await cart.save();
    
    res.json({
      success: true,
      message: 'Cart cleared',
      data: cart
    });
  } catch (error) {
    console.error('Error clearing cart:', error);
    res.status(500).json({
      success: false,
      error: 'Server Error',
      message: error.message
    });
  }
});

module.exports = router;
''',

    "routes/checkout.js": '''// routes/checkout.js - Checkout Routes
const express = require('express');
const router = express.Router();
const Cart = require('../models/Cart');
const Order = require('../models/Order');

const DEFAULT_USER_ID = process.env.DEFAULT_USER_ID || 'user_12345';

// @route   POST /api/checkout
// @desc    Process checkout and create order
// @access  Public
router.post('/', async (req, res) => {
  try {
    const {
      userId = DEFAULT_USER_ID,
      customerName,
      customerEmail,
      customerPhone,
      customerAddress
    } = req.body;
    
    // Validate required fields
    if (!customerName || !customerEmail) {
      return res.status(400).json({
        success: false,
        error: 'Customer name and email are required'
      });
    }
    
    // Get user's cart
    const cart = await Cart.findOne({ userId });
    if (!cart || cart.items.length === 0) {
      return res.status(400).json({
        success: false,
        error: 'Cart is empty'
      });
    }
    
    // Generate unique order ID
    const orderId = `ORD-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
    
    // Create order
    const order = await Order.create({
      orderId,
      userId,
      customerName,
      customerEmail,
      customerPhone: customerPhone || '',
      customerAddress: customerAddress || '',
      items: cart.items.map(item => ({
        productId: item.productId,
        title: item.title,
        price: item.price,
        quantity: item.quantity
      })),
      subtotal: cart.subtotal,
      tax: cart.tax,
      total: cart.total,
      status: 'pending'
    });
    
    // Clear cart after successful order
    cart.items = [];
    await cart.save();
    
    res.status(201).json({
      success: true,
      message: 'Order placed successfully',
      data: {
        orderId: order.orderId,
        customerName: order.customerName,
        customerEmail: order.customerEmail,
        items: order.items,
        subtotal: order.subtotal,
        tax: order.tax,
        total: order.total,
        timestamp: order.createdAt
      }
    });
  } catch (error) {
    console.error('Error processing checkout:', error);
    res.status(500).json({
      success: false,
      error: 'Server Error',
      message: error.message
    });
  }
});

// @route   GET /api/checkout/orders
// @desc    Get user's order history
// @access  Public
router.get('/orders', async (req, res) => {
  try {
    const userId = req.query.userId || DEFAULT_USER_ID;
    const orders = await Order.find({ userId }).sort({ createdAt: -1 });
    
    res.json({
      success: true,
      count: orders.length,
      data: orders
    });
  } catch (error) {
    console.error('Error fetching orders:', error);
    res.status(500).json({
      success: false,
      error: 'Server Error',
      message: error.message
    });
  }
});

// @route   GET /api/checkout/orders/:orderId
// @desc    Get specific order details
// @access  Public
router.get('/orders/:orderId', async (req, res) => {
  try {
    const order = await Order.findOne({ orderId: req.params.orderId });
    
    if (!order) {
      return res.status(404).json({
        success: false,
        error: 'Order not found'
      });
    }
    
    res.json({
      success: true,
      data: order
    });
  } catch (error) {
    console.error('Error fetching order:', error);
    res.status(500).json({
      success: false,
      error: 'Server Error',
      message: error.message
    });
  }
});

module.exports = router;
''',

    "utils/seedProducts.js": '''// utils/seedProducts.js - Seed mock products into database
const mongoose = require('mongoose');
require('dotenv').config();
const Product = require('../models/Product');

const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/vibe-commerce';

const mockProducts = [
  {
    title: "Premium Wireless Headphones",
    price: 299.99,
    description: "High-quality wireless headphones with noise cancellation and 30-hour battery life",
    category: "electronics",
    image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=300&h=300&fit=crop",
    rating: { rate: 4.8, count: 245 },
    stock: 50
  },
  {
    title: "Smart Watch Pro",
    price: 399.99,
    description: "Advanced smartwatch with fitness tracking, heart rate monitor, and GPS",
    category: "electronics",
    image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=300&h=300&fit=crop",
    rating: { rate: 4.6, count: 189 },
    stock: 75
  },
  {
    title: "Leather Laptop Bag",
    price: 129.99,
    description: "Genuine leather laptop bag with multiple compartments and padded protection",
    category: "accessories",
    image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=300&h=300&fit=crop",
    rating: { rate: 4.7, count: 156 },
    stock: 40
  },
  {
    title: "Ergonomic Office Chair",
    price: 449.99,
    description: "Premium ergonomic office chair with lumbar support and adjustable features",
    category: "furniture",
    image: "https://images.unsplash.com/photo-1580480055273-228ff5388ef8?w=300&h=300&fit=crop",
    rating: { rate: 4.9, count: 312 },
    stock: 25
  },
  {
    title: "Stainless Steel Water Bottle",
    price: 34.99,
    description: "Insulated stainless steel water bottle keeps drinks cold for 24 hours",
    category: "accessories",
    image: "https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=300&h=300&fit=crop",
    rating: { rate: 4.5, count: 428 },
    stock: 150
  },
  {
    title: "Wireless Gaming Mouse",
    price: 79.99,
    description: "High-precision wireless gaming mouse with RGB lighting and programmable buttons",
    category: "electronics",
    image: "https://images.unsplash.com/photo-1527814050087-3793815479db?w=300&h=300&fit=crop",
    rating: { rate: 4.6, count: 267 },
    stock: 80
  },
  {
    title: "Yoga Mat Premium",
    price: 59.99,
    description: "Extra-thick yoga mat with non-slip surface and carrying strap",
    category: "sports",
    image: "https://images.unsplash.com/photo-1601925260368-ae2f83cf8b7f?w=300&h=300&fit=crop",
    rating: { rate: 4.7, count: 198 },
    stock: 100
  },
  {
    title: "Coffee Maker Deluxe",
    price: 189.99,
    description: "Programmable coffee maker with thermal carafe and brew strength control",
    category: "appliances",
    image: "https://images.unsplash.com/photo-1517668808822-9ebb02f2a0e6?w=300&h=300&fit=crop",
    rating: { rate: 4.4, count: 342 },
    stock: 45
  },
  {
    title: "Mechanical Keyboard RGB",
    price: 149.99,
    description: "Mechanical gaming keyboard with customizable RGB lighting and Cherry MX switches",
    category: "electronics",
    image: "https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=300&h=300&fit=crop",
    rating: { rate: 4.8, count: 523 },
    stock: 60
  },
  {
    title: "Designer Sunglasses",
    price: 199.99,
    description: "Premium designer sunglasses with UV protection and polarized lenses",
    category: "accessories",
    image: "https://images.unsplash.com/photo-1572635196237-14b3f281503f?w=300&h=300&fit=crop",
    rating: { rate: 4.5, count: 176 },
    stock: 35
  }
];

async function seedDatabase() {
  try {
    // Connect to MongoDB
    await mongoose.connect(MONGO_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    console.log('✅ Connected to MongoDB');
    
    // Clear existing products
    await Product.deleteMany({});
    console.log('🗑️  Cleared existing products');
    
    // Insert mock products
    const products = await Product.insertMany(mockProducts);
    console.log(`✅ Successfully seeded ${products.length} products`);
    
    console.log('\\n📦 Sample Products:');
    products.slice(0, 3).forEach(product => {
      console.log(`  - ${product.title}: $${product.price}`);
    });
    
    process.exit(0);
  } catch (error) {
    console.error('❌ Error seeding database:', error);
    process.exit(1);
  }
}

seedDatabase();
'''
}

# Save the file structure information
print("Backend file structure created successfully!")
print("\nFiles generated:")
for filename in backend_code.keys():
    print(f"  ✓ {filename}")
